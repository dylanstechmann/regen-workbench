# Engineered tissues & repair

Research hypothesis. Computational outputs, source reports, and demonstrated effects remain distinct.

## Query

engineered cartilage skin vascular graft functional clinical trial

## Question

When does an engineered tissue restore durable function in an aging or damaged body?

## Who

Keep human graft trials, perfused constructs and animal implants distinct.

## What

Engineered cartilage, skin, blood vessels and muscle with measurable structure and function.

## Where

Vascular supply, extracellular matrix, host interface and immune compatibility.

## When

Early graft survival, healing speed and function months or years later are separate outcomes.

## Why

Cell survival and a tissue-like shape do not guarantee mechanical or physiological function.

## How

Compare graft maturation, perfusion, donor-site demand, integration and patient-relevant function from primary trials and experimental tissue datasets.

## Falsifier

A graft survives but heals slowly, loses function, scars or fails mechanical integration.

## Desired Changes

Improve functional integration and durable repair, including tests of genome-corrected engineered tissue.

## Source-reviewed starting points

- In a randomized phase II trial of focal knee defects, mature nasal-chondrocyte engineered cartilage produced a median KOOS of 85 versus 79 for a less-mature cell-activated matrix at 24 months; the adjusted difference was 7.27 points. An open-label active-comparator trial for focal defects, not reversal of diffuse osteoarthritis or whole-body aging. The patient-reported score does not alone establish lifelong graft durability. Source: https://pubmed.ncbi.nlm.nih.gov/40043142/

- In a 23-person intra-patient randomized phase II trial, bio-engineered autologous skin had a better observer scar score at three months (23.4 versus 27.9) and greater coverage per donor area (8.5 versus 0.9) than split-thickness grafts. Median wound closure took 60.5 versus 22 days, and early graft take was 69.8% versus 85.0%. This is reconstruction of defects, not scar-free or age-reversed skin. Source: https://pubmed.ncbi.nlm.nih.gov/41890789/

- Base-edited patient-derived vascular cells yielded perfused tissue-engineered vessels with restored vasodilation and smooth-muscle density; constructs starting with at least 50% edited smooth-muscle cells improved several markers. An in-vitro human tissue model of one monogenic accelerated-aging disorder. It does not show transplantation, correction of normal age-acquired mutations or clinical vascular rejuvenation. Source: https://pubmed.ncbi.nlm.nih.gov/40027545/

- A phase I/IIa study implanted a stem-cell-derived retinal-pigment-epithelium monolayer on a scaffold in 15 older adults with advanced geographic atrophy; four treated eyes gained more than five visual-acuity letters at one year. Single-arm safety study with a non-significant fellow-eye comparison, not demonstrated efficacy. Serious ocular events occurred in early recipients; tissue implantation did not restore normal vision. Source: https://pubmed.ncbi.nlm.nih.gov/34613357/

## Immutable research-design revisions

- plan_freeze · GSE160356 freeze before scoring · revision 1 · current revision · SHA-256 4a72d9bb93dd94cd5af67132b808ddc79d163b59dfa8f5137f435ca6d18e2c62

  - Freeze status exploratory; claim state exploratory_only; final-test groups sealed 6; ledger events 0 (head none); pinned inputs resolve: True; record supports a confirmatory claim: False. This is procedural bookkeeping, not a result or a review.

- analysis_plan · GSE160356 prespecified control-bin check · revision 1 · current revision · SHA-256 e50197e3a5e80a595ad01444c8a2de2349f1efba0409ff1651134a027cf71b65

- dataset_card · GSE160356 HRMEC count tables · revision 1 · current revision · SHA-256 b20f67a1ff9a4124d2d1877f6b8d1df582341bb407d923c0251c856b052317a4

- question · GSE160356 endothelial passage and etoposide question · revision 1 · current revision · SHA-256 4ba9dfa4521468a294c5b64d183af9eafdaf2515cf99deaf9fc298d1443f805a

Citation URLs in these records are stored as references and were not fetched by ResearchDesk. Draft plans do not execute analyses or establish dataset eligibility.

## Target-centered campaigns

## Private notes
0 manually entered note(s) excluded from this export.

## Reproducible runs