# Engineered tissues & repair

Research hypothesis. Computational outputs, source reports, and demonstrated effects remain distinct.

## Query

engineered cartilage skin vascular graft functional clinical trial

## Question

When does an engineered tissue restore durable function in an aging or damaged body?

## Who

Keep human graft trials, perfused constructs and animal implants distinct.

## What

Engineered cartilage, skin, blood vessels and muscle with measurable structure and function.

## Where

Vascular supply, extracellular matrix, host interface and immune compatibility.

## When

Early graft survival, healing speed and function months or years later are separate outcomes.

## Why

Cell survival and a tissue-like shape do not guarantee mechanical or physiological function.

## How

Compare graft maturation, perfusion, donor-site demand, integration and patient-relevant function from primary trials and experimental tissue datasets.

## Falsifier

A graft survives but heals slowly, loses function, scars or fails mechanical integration.

## Desired Changes

Improve functional integration and durable repair, including tests of genome-corrected engineered tissue.

## Source-reviewed starting points

- In a randomized phase II trial of focal knee defects, mature nasal-chondrocyte engineered cartilage produced a median KOOS of 85 versus 79 for a less-mature cell-activated matrix at 24 months; the adjusted difference was 7.27 points. An open-label active-comparator trial for focal defects, not reversal of diffuse osteoarthritis or whole-body aging. The patient-reported score does not alone establish lifelong graft durability. Source: https://pubmed.ncbi.nlm.nih.gov/40043142/

- In a 23-person intra-patient randomized phase II trial, bio-engineered autologous skin had a better observer scar score at three months (23.4 versus 27.9) and greater coverage per donor area (8.5 versus 0.9) than split-thickness grafts. Median wound closure took 60.5 versus 22 days, and early graft take was 69.8% versus 85.0%. This is reconstruction of defects, not scar-free or age-reversed skin. Source: https://pubmed.ncbi.nlm.nih.gov/41890789/

- Base-edited patient-derived vascular cells yielded perfused tissue-engineered vessels with restored vasodilation and smooth-muscle density; constructs starting with at least 50% edited smooth-muscle cells improved several markers. An in-vitro human tissue model of one monogenic accelerated-aging disorder. It does not show transplantation, correction of normal age-acquired mutations or clinical vascular rejuvenation. Source: https://pubmed.ncbi.nlm.nih.gov/40027545/

- A phase I/IIa study implanted a stem-cell-derived retinal-pigment-epithelium monolayer on a scaffold in 15 older adults with advanced geographic atrophy; four treated eyes gained more than five visual-acuity letters at one year. Single-arm safety study with a non-significant fellow-eye comparison, not demonstrated efficacy. Serious ocular events occurred in early recipients; tissue implantation did not restore normal vision. Source: https://pubmed.ncbi.nlm.nih.gov/34613357/

## Immutable research-design revisions

- evaluation_binding · SYNTHETIC final-test receipt · revision 1 · current revision · SHA-256 7011c7f039a41cd6d436e9f9dadf74039ab4ad2f28cdf32d8ff37b401c978e06

  - Binding bound_prospective at the final_test stage for receipt 9ecb24ff3e0997e894ab51e71e63a775b267a8de68a9deb039c36a5a00e0f64e.

- holdout_access · Synthetic access · revision 1 · current revision · SHA-256 6755b91eae47f28c86af1e6094d75a478e779f229e7ce7a99a43d06b4c5f7d37

- holdout_access · Synthetic access · revision 1 · current revision · SHA-256 e3b6a38982348999f3f216ec8588feffc8c1e3f0d6ce4dcc96b9c5db9b6db5f9

- plan_freeze · SYNTHETIC prospective freeze · revision 1 · current revision · SHA-256 a11573501bf4f0eea5bffc24e53084ea94af6721855f07e4f00523f40fa434ac

  - Freeze status confirmatory; claim state single_final_evaluation_recorded; final-test groups sealed 1; ledger events 2 (head 6755b91eae47f28c86af1e6094d75a478e779f229e7ce7a99a43d06b4c5f7d37); pinned inputs resolve: True; record supports a confirmatory claim: True. This is procedural bookkeeping, not a result or a review.

- analysis_plan · SYNTHETIC confirmatory plan · revision 1 · current revision · SHA-256 e06e2d0f807770c7fffd118b1de6ae3445dc63336cc6851505dc19e13d95f542

- dataset_card · SYNTHETIC table · revision 1 · current revision · SHA-256 7e6a13fb5caf3f25d6eee07b76150bbbcd28c98dcbbc603bc2cca58629242c2d

- question · SYNTHETIC procedure question · revision 1 · current revision · SHA-256 9becd39b511dd3d4d4fa70f5969c31d4a94d68d8a26d97fff0b45c90ed41ebc7

- evaluation_binding · NIST receipt as the final-test evaluation · revision 1 · current revision · SHA-256 812e39f4362192e4769acae44623295a5d342bd7561a106362ea16a3a657889d

  - Binding mismatch at the final_test stage for receipt 7cd440e0ff4c66975966712015c974a6d866e574fba0859506a404f158391f7c.

- evaluation_binding · NIST receipt as a development run · revision 1 · current revision · SHA-256 eeb36b35fff2afc9f433a027ff935db3de13eef45bfb0798c247036f7b337560

  - Binding mismatch at the development stage for receipt 7cd440e0ff4c66975966712015c974a6d866e574fba0859506a404f158391f7c.

- plan_freeze · What-if: seal training_high · revision 1 · current revision · SHA-256 9e465e8d411efbea47e2a29fdffd4a5618c7762b7de142f10837ff5391cf7a46

  - Freeze status retrospective; claim state holdout_compromised; final-test groups sealed 1; ledger events 0 (head none); pinned inputs resolve: True; record supports a confirmatory claim: False. This is procedural bookkeeping, not a result or a review.

- evaluation_binding · NIST receipt, development stage · revision 1 · current revision · SHA-256 41cd5a773b4aea5a079922ccda01c804915e0099389fa92b55097eedf2695829

  - Binding bound_retrospective at the development stage for receipt 7cd440e0ff4c66975966712015c974a6d866e574fba0859506a404f158391f7c.

- plan_freeze · As run: three development wells · revision 1 · current revision · SHA-256 9dbb40b1e2e1d4cfd5084881b1325f50dd05819c1d52f6b1484000fdf55169d2

  - Freeze status retrospective; claim state retrospective_not_confirmatory; final-test groups sealed 0; ledger events 0 (head none); pinned inputs resolve: True; record supports a confirmatory claim: False. This is procedural bookkeeping, not a result or a review.

- analysis_plan · Retrospective description of the NIST benchmark · revision 1 · current revision · SHA-256 1f06fa0bf66d54691420614f06d6fee58d52425c6d236e8cfa6af463bfec02b7

- dataset_card · NIST derived feature table · revision 1 · current revision · SHA-256 5d60611cb4682f70569a353dec21ab337c5f1d85b34abdc09a9833c96ba09bb8

- question · NIST well-holdout question · revision 1 · current revision · SHA-256 14122fff9115fbec277dcebc9be59310028f0986e5d706023b399d746ba6957e

Citation URLs in these records are stored as references and were not fetched by ResearchDesk. Draft plans do not execute analyses or establish dataset eligibility.

## Target-centered campaigns

## Private notes
0 manually entered note(s) excluded from this export.

## Reproducible runs